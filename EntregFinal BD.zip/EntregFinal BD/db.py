import mysql.connector

#Conexión con base de datos en Workbench
def conectar():
    return mysql.connector.connect(
        host="localhost",
        user="root",          
        password="W0k-18*kash",     
        database="NODO_Data_Base"
    )

