from reportes_admin import menu_reportes
from db import conectar
import random
import string
from datetime import date
 
def matricular_usuario():
    conn = conectar()
    cursor = conn.cursor()
 
    try:
        id_usuario = input("Ingrese el ID del usuario a matricular: ").strip()
        id_curso = input("Ingrese el ID del curso para matricular: ").strip()
 
        # Obtener id_estudiante asociado al id_usuario
        cursor.execute("SELECT id_estudiante FROM Estudiante WHERE id_usuario = %s", (id_usuario,))
        resultado = cursor.fetchone()
        if not resultado:
            print("El usuario no es un estudiante o no existe en la tabla Estudiante.")
            return
        id_estudiante = resultado[0]
 
        # Verificamos si ya está matriculado
        cursor.execute("SELECT * FROM Matricula WHERE id_estudiante = %s AND id_curso = %s", (id_estudiante, id_curso))
        if cursor.fetchone():
            print("El estudiante ya está matriculado en ese curso.")
            return
 
        # Generamos una contraseña de acceso aleatoria
        contrasena_acceso = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
 
        fecha_hoy = date.today().isoformat()
 
        # Insertamos la nueva matrícula en la tabla MAtricula
        cursor.execute(
            "INSERT INTO Matricula (fecha_matricula, contrasena_acceso, id_estudiante, id_curso) VALUES (%s, %s, %s, %s)",
            (fecha_hoy, contrasena_acceso, id_estudiante, id_curso)
        )
        conn.commit()
 
        print(f"Estudiante matriculado exitosamente con contraseña de acceso: {contrasena_acceso}")
    except Exception as e:
        print("Error al matricular usuario:", e)
    finally:
        cursor.close()
        conn.close()
 
 #Asiignar profesor a curso
def asignar_profesor():
    conn = conectar()
    cursor = conn.cursor()
 
    try:
        id_curso = input("Ingrese el ID del curso para asignar profesor: ").strip()
        id_profesor = input("Ingrese el ID del profesor: ").strip()
 
        # Validamos curso
        cursor.execute("SELECT * FROM Curso WHERE id_curso = %s", (id_curso,))
        if not cursor.fetchone():
            print("Curso no encontrado.")
            return
 
        # Validamos profesor
        cursor.execute("SELECT * FROM Profesor WHERE id_profesor = %s", (id_profesor,))
        if not cursor.fetchone():
            print("Profesor no encontrado.")
            return
 
        # Actualizar curso con el profesor asignado
        cursor.execute(
            "UPDATE Curso SET id_profesor = %s WHERE id_curso = %s",
            (id_profesor, id_curso)
        )
        conn.commit()
 
        print(f"Profesor {id_profesor} asignado al curso {id_curso} exitosamente.")
    except Exception as e:
        print("Error al asignar profesor:", e)
    finally:
        cursor.close()
        conn.close()
 
def menu_administrador():
    while True:
        print("\n--- Menú Administrador ---")
        print("1. Matricular usuario a un curso")
        print("2. Asignar profesor a un curso")
        print("3. Reportes")
        print("4. Salir")
 
        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            matricular_usuario()
        elif opcion == "2":
            asignar_profesor()
        elif opcion == "3":
            menu_reportes()
        elif opcion == "4":
            print("Saliendo del menú administrador...")
            break
        else:
            print("Opción inválida. Intente de nuevo.")
