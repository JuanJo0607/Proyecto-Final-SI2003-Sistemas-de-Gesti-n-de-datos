from db import conectar

#Autenticar el usuario
def login(email, contrasena):
    conn = conectar()
    cursor = conn.cursor(dictionary=True)

    query = """
    SELECT id_usuario, nombre, apellido, email
    FROM Usuario
    WHERE email = %s AND contrasena = %s
    """
    cursor.execute(query, (email, contrasena))
    usuario = cursor.fetchone()

    cursor.close()
    conn.close()

    if usuario:
        print(f"Bienvenido {usuario['nombre']} {usuario['apellido']} (ID: {usuario['id_usuario']})")
        return usuario 
    else:
        print("Credenciales incorrectas.")
        return None

def logout(usuario):
    if usuario:
        print(f"Hasta luego, {usuario['nombre']}!")
    else:
        print("Ningún usuario ha iniciado sesión.")
