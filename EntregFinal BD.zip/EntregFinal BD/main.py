from db import conectar
from admin_menu import menu_administrador
from profesor_alumno_menu import menu_profesor_alumno 
 
def login():
    print("=== INICIO DE SESIÓN ===")
    email = input("Correo electrónico: ").strip()
    contrasena = input("Contraseña: ").strip()
 
    conn = conectar()
    cursor = conn.cursor(dictionary=True)
 
    query = """
    SELECT id_usuario, nombre, apellido, email
    FROM Usuario
    WHERE email = %s AND contrasena = %s
    """
    cursor.execute(query, (email, contrasena))
    usuario = cursor.fetchone()
 
    if not usuario:
        print("\nCredenciales incorrectas.\n")
        cursor.close()
        conn.close()
        return None
 
    id_usuario = usuario['id_usuario']
 
    # Verificamos el tipo de usuario
    tipo_usuario = "Desconocido"
 
    cursor.execute("SELECT 1 FROM Estudiante WHERE id_usuario = %s", (id_usuario,))
    if cursor.fetchone():
        tipo_usuario = "Estudiante"
 
    cursor.execute("SELECT 1 FROM Profesor WHERE id_usuario = %s", (id_usuario,))
    if cursor.fetchone():
        tipo_usuario = "Profesor"
 
    cursor.execute("SELECT 1 FROM Administrador WHERE id_usuario = %s", (id_usuario,))
    if cursor.fetchone():
        tipo_usuario = "Administrador"
 
    print(f"\nBienvenido {usuario['nombre']} {usuario['apellido']} ({tipo_usuario})\n")
 
    cursor.close()
    conn.close()
    usuario["rol"] = tipo_usuario  
    return usuario
 
 
def logout(usuario):
    if usuario:
        print(f"Hasta luego, {usuario['nombre']}!\n")
    else:
        print("No hay sesión activa.\n")
 
 
def main():
    usuario = None
 
    while True:
        if usuario is None:
            print("===== MENÚ PRINCIPAL =====")
            print("1. Iniciar sesión")
            print("2. Salir")
            opcion = input("Seleccione una opción: ").strip()
 
            if opcion == "1":
                usuario = login()
            elif opcion == "2":
                print("Saliendo del sistema...")
                break
            else:
                print("Opción no válida.\n")
        else:
            # Menús según rol
            if usuario["rol"] == "Administrador":
                menu_administrador()
            elif usuario["rol"] in ["Profesor", "Estudiante"]:
                menu_profesor_alumno(usuario)
            else:
                print("Rol desconocido, cerrando sesión.")
 
            usuario = None
 
 
if __name__ == "__main__":
    main()