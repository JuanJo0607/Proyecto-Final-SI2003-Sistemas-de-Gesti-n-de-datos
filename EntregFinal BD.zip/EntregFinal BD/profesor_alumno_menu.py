from db import conectar
from datetime import datetime

def listar_cursos(usuario):
    conn = conectar()
    cursor = conn.cursor(dictionary=True)

    try:
        if usuario['rol'] == "Profesor":
            # Obtenemos el id_profesor
            cursor.execute("SELECT id_profesor FROM Profesor WHERE id_usuario = %s", (usuario['id_usuario'],))
            res = cursor.fetchone()
            if not res:
                print("No se encontró el profesor en la base de datos.")
                return []
            id_profesor = res['id_profesor']

            # Listamos cursos dictados por el profesor
            cursor.execute("""
                SELECT id_curso, nombre, categoria 
                FROM Curso 
                WHERE id_profesor = %s
            """, (id_profesor,))
            cursos = cursor.fetchall()

        elif usuario['rol'] == "Estudiante":
            # Obtenemos id_estudiante
            cursor.execute("SELECT id_estudiante FROM Estudiante WHERE id_usuario = %s", (usuario['id_usuario'],))
            res = cursor.fetchone()
            if not res:
                print("No se encontró el estudiante en la base de datos.")
                return []
            id_estudiante = res['id_estudiante']

            # Listamos cursos donde está matriculado el estudiante
            cursor.execute("""
                SELECT c.id_curso, c.nombre, c.categoria
                FROM Curso c
                JOIN Matricula m ON c.id_curso = m.id_curso
                WHERE m.id_estudiante = %s
            """, (id_estudiante,))
            cursos = cursor.fetchall()
        else:
            print("Rol no soportado para listar cursos.")
            cursos = []

        if not cursos:
            print("No hay cursos asignados o matriculados.")
            return []

        print("\n--- Cursos disponibles ---")
        for idx, curso in enumerate(cursos, start=1):
            print(f"{idx}. [{curso['id_curso']}] {curso['nombre']} ({curso['categoria']})")
        return cursos

    except Exception as e:
        print("Error listando cursos:", e)
        return []
    finally:
        cursor.close()
        conn.close()

def listar_alumnos(id_curso):
    conn = conectar()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT u.id_usuario, u.nombre, u.apellido, e.id_estudiante
            FROM Usuario u
            JOIN Estudiante e ON u.id_usuario = e.id_usuario
            JOIN Matricula m ON e.id_estudiante = m.id_estudiante
            WHERE m.id_curso = %s
        """, (id_curso,))
        alumnos = cursor.fetchall()
        if not alumnos:
            print("No hay alumnos matriculados en este curso.")
            return

        print("\n--- Alumnos matriculados ---")
        for alumno in alumnos:
            print(f"- {alumno['nombre']} {alumno['apellido']} (ID Usuario: {alumno['id_usuario']})")
    except Exception as e:
        print("Error listando alumnos:", e)
    finally:
        cursor.close()
        conn.close()

def listar_materiales(id_curso):
    conn = conectar()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT m.id_material, m.titulo, m.descripcion
            FROM Material m
            WHERE m.id_curso = %s
        """, (id_curso,))
        materiales = cursor.fetchall()
        if not materiales:
            print("No hay materiales para este curso.")
            return

        print("\n--- Materiales del curso ---")
        for mat in materiales:
            print(f"- [{mat['id_material']}] {mat['titulo']}: {mat['descripcion']}")
    except Exception as e:
        print("Error listando materiales:", e)
    finally:
        cursor.close()
        conn.close()

def listar_foros(id_curso):
    conn = conectar()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT id_foro, nombre, descripcion, fecha_creacion, fecha_terminacion
            FROM Foro
            WHERE id_curso = %s
        """, (id_curso,))
        foros = cursor.fetchall()
        if not foros:
            print("No hay foros en este curso.")
            return []

        print("\n--- Foros del curso ---")
        for foro in foros:
            fecha_fin = foro['fecha_terminacion'].strftime("%Y-%m-%d") if foro['fecha_terminacion'] else "Sin fecha"
            print(f"[{foro['id_foro']}] {foro['nombre']} (Cierre: {fecha_fin}) - {foro['descripcion']}")
        return foros
    except Exception as e:
        print("Error listando foros:", e)
        return []
    finally:
        cursor.close()
        conn.close()

def enviar_mensaje_foro(usuario, id_foro):
    conn = conectar()
    cursor = conn.cursor()

    try:
        nombre_msg = input("Nombre del mensaje: ").strip()
        descripcion_msg = input("Contenido del mensaje: ").strip()

        cursor.execute("""
            INSERT INTO Mensaje (nombre, descripcion, id_foro, id_usuario, id_mensaje_replicado)
            VALUES (%s, %s, %s, %s, NULL)
        """, (nombre_msg, descripcion_msg, id_foro, usuario['id_usuario']))
        conn.commit()
        print("Mensaje enviado al foro correctamente.")
    except Exception as e:
        print("Error enviando mensaje:", e)
    finally:
        cursor.close()
        conn.close()

def responder_mensaje(usuario, id_foro):
    conn = conectar()
    cursor = conn.cursor(dictionary=True)

    try:
        # Listamos mensajes en el foro
        cursor.execute("""
            SELECT id_mensaje, nombre, descripcion, id_usuario, id_mensaje_replicado
            FROM Mensaje
            WHERE id_foro = %s
            ORDER BY id_mensaje
        """, (id_foro,))
        mensajes = cursor.fetchall()
        if not mensajes:
            print("No hay mensajes en este foro.")
            return

        print("\n--- Mensajes en el foro ---")
        for msg in mensajes:
            prefix = "(Replica)" if msg['id_mensaje_replicado'] else ""
            print(f"[{msg['id_mensaje']}] {prefix} {msg['nombre']}: {msg['descripcion']} (Usuario ID: {msg['id_usuario']})")

        id_msg = input("Ingrese el ID del mensaje al que quiere replicar: ").strip()
        # Validamos id_msg
        if not any(str(m['id_mensaje']) == id_msg for m in mensajes):
            print("ID de mensaje inválido.")
            return

        nombre_replica = input("Nombre de la réplica: ").strip()
        descripcion_replica = input("Contenido de la réplica: ").strip()

        cursor.execute("""
            INSERT INTO Mensaje (nombre, descripcion, id_foro, id_usuario, id_mensaje_replicado)
            VALUES (%s, %s, %s, %s, %s)
        """, (nombre_replica, descripcion_replica, id_foro, usuario['id_usuario'], id_msg))
        conn.commit()
        print("Réplicas enviada correctamente.")
    except Exception as e:
        print("Error respondiendo mensaje:", e)
    finally:
        cursor.close()
        conn.close()

def listar_tareas(id_curso):
    conn = conectar()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT id_tarea, nombre, descripcion, fecha_creacion, fecha_entrega, puntaje, nombre_archivo
            FROM Tarea
            WHERE id_curso = %s
        """, (id_curso,))
        tareas = cursor.fetchall()
        if not tareas:
            print("No hay tareas en este curso.")
            return

        print("\n--- Tareas del curso ---")
        for tarea in tareas:
            fecha_entrega = tarea['fecha_entrega'].strftime("%Y-%m-%d") if tarea['fecha_entrega'] else "Sin fecha"
            print(f"[{tarea['id_tarea']}] {tarea['nombre']} - Entrega: {fecha_entrega} - Puntaje: {tarea['puntaje']}")
            print(f"Archivo: {tarea['nombre_archivo']}")
            print(f"Descripción: {tarea['descripcion']}\n")
    except Exception as e:
        print("Error listando tareas:", e)
    finally:
        cursor.close()
        conn.close()

def subir_material(id_curso):
    conn = conectar()
    cursor = conn.cursor()

    try:
        titulo = input("Título del material: ").strip()
        descripcion = input("Descripción del material: ").strip()
        url_archivo = input("URL ficticia del archivo (simulado): ").strip()

        # Insertamos material
        cursor.execute("""
            INSERT INTO Material (titulo, descripcion, id_curso)
            VALUES (%s, %s, %s)
        """, (titulo, descripcion, id_curso))
        conn.commit()

        # Obtenemos id_material recién insertado
        cursor.execute("SELECT LAST_INSERT_ID()")
        id_material = cursor.fetchone()[0]

        # Insertamos archivo material de forma simulada
        cursor.execute("""
            INSERT INTO Archivo_Material (nombre_archivo, id_material)
            VALUES (%s, %s)
        """, (url_archivo, id_material))
        conn.commit()

        print("Material subido correctamente (simulado).")
    except Exception as e:
        print("Error subiendo material:", e)
    finally:
        cursor.close()
        conn.close()

def crear_foro(id_curso):
    conn = conectar()
    cursor = conn.cursor()

    try:
        nombre = input("Nombre del foro: ").strip()
        descripcion = input("Descripción del foro: ").strip()
        fecha_creacion = datetime.today().date()
        fecha_terminacion = input("Fecha de terminación (YYYY-MM-DD) o dejar vacío: ").strip()
        if fecha_terminacion == "":
            fecha_terminacion = None

        cursor.execute("""
            INSERT INTO Foro (nombre, descripcion, fecha_creacion, fecha_terminacion, id_curso)
            VALUES (%s, %s, %s, %s, %s)
        """, (nombre, descripcion, fecha_creacion, fecha_terminacion, id_curso))
        conn.commit()
        print("Foro creado correctamente.")
    except Exception as e:
        print("Error creando foro:", e)
    finally:
        cursor.close()
        conn.close()

def menu_curso(usuario, id_curso):
    while True:
        print("\n--- Menú del Curso ---")
        print("1. Listar Alumnos (solo profesor)")
        print("2. Listar Materiales")
        print("3. Foros (enviar y responder mensajes)")
        print("4. Listar Tareas")
        if usuario['rol'] == "Profesor":
            print("5. Subir Material (simulado)")
            print("6. Crear Foro")
            print("7. Salir del curso")
            opciones_validas = {"1", "2", "3", "4", "5", "6", "7"}
        else:
            print("5. Salir del curso")
            opciones_validas = {"1", "2", "3", "4", "5"}

        opcion = input("Seleccione una opción: ").strip()

        if opcion not in opciones_validas:
            print("Opción inválida. Intente de nuevo.")
            continue

        if opcion == "1" and usuario['rol'] == "Profesor":
            listar_alumnos(id_curso)
        elif opcion == "2":
            listar_materiales(id_curso)
        elif opcion == "3":
            foros = listar_foros(id_curso)
            if not foros:
                continue
            id_foro = input("Ingrese el ID del foro para enviar o responder mensajes (o dejar vacío para cancelar): ").strip()
            if not id_foro:
                continue
            while True:
                print("\n1. Enviar mensaje")
                print("2. Responder mensaje")
                print("3. Volver al menú del curso")
                subop = input("Seleccione una opción: ").strip()
                if subop == "1":
                    enviar_mensaje_foro(usuario, id_foro)
                elif subop == "2":
                    responder_mensaje(usuario, id_foro)
                elif subop == "3":
                    break
                else:
                    print("Opción inválida.")
        elif opcion == "4":
            listar_tareas(id_curso)
        elif opcion == "5":
            if usuario['rol'] == "Profesor":
                subir_material(id_curso)
            else:
                print("Saliendo del curso...")
                break
        elif opcion == "6" and usuario['rol'] == "Profesor":
            crear_foro(id_curso)
        elif opcion == "7" and usuario['rol'] == "Profesor":
            print("Saliendo del curso...")
            break

def menu_profesor_alumno(usuario):
    while True:
        cursos = listar_cursos(usuario)
        if not cursos:
            print("No tiene cursos asignados o matriculados. Saliendo...")
            break
        print("\nSeleccione un curso o ingrese 0 para salir:")
        opcion = input("Opción: ").strip()
        if opcion == "0":
            print("Saliendo del menú de cursos.")
            break
        if not opcion.isdigit() or int(opcion) < 1 or int(opcion) > len(cursos):
            print("Opción inválida.")
            continue

        id_curso = cursos[int(opcion) -1]['id_curso']
        menu_curso(usuario, id_curso)