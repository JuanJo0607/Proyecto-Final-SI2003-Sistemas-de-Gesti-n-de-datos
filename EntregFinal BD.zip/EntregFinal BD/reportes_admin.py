from db import conectar

def menu_reportes():
    while True:
        print("\n===== REPORTES ADMINISTRADOR =====")
        print("1. Listar cursos con filtros")
        print("2. Ver detalles de un curso")
        print("3. Listar usuarios con filtros")
        print("0. Volver al menú anterior")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            listar_cursos()
        elif opcion == "2":
            detalle_curso()
        elif opcion == "3":
            listar_usuarios()
        elif opcion == "0":
            break
        else:
            print("Opción inválida")


def listar_cursos():
    conn = conectar()
    cursor = conn.cursor()

    print("\nFiltros disponibles:")
    print("1. Todos")
    print("2. Por ID de curso")
    print("3. Por ID de profesor")
    print("4. Por rango de fechas")
    filtro = input("Seleccione filtro: ")

    try:
        if filtro == "1":
            cursor.execute("SELECT id_curso, nombre, fecha_inicio, fecha_fin FROM Curso")
        elif filtro == "2":
            id_curso = input("Ingrese ID del curso: ")
            cursor.execute("SELECT id_curso, nombre, fecha_inicio, fecha_fin FROM Curso WHERE id_curso = %s", (id_curso,))
        elif filtro == "3":
            id_prof = input("Ingrese ID del profesor: ")
            cursor.execute("SELECT id_curso, nombre, fecha_inicio, fecha_fin FROM Curso WHERE id_profesor = %s", (id_prof,))
        elif filtro == "4":
            desde = input("Fecha inicio (YYYY-MM-DD): ")
            hasta = input("Fecha fin (YYYY-MM-DD): ")
            cursor.execute("SELECT id_curso, nombre, fecha_inicio, fecha_fin FROM Curso WHERE fecha_inicio >= %s AND fecha_fin <= %s", (desde, hasta))
        else:
            print("Filtro inválido.")
            return

        print("\nCursos encontrados:")
        for id_curso, nombre, fi, ff in cursor.fetchall():
            print(f"{id_curso}: {nombre} ({fi} a {ff})")

    except Exception as e:
        print("Error:", e)
    finally:
        cursor.close()
        conn.close()

def detalle_curso():
    conn = conectar()
    cursor = conn.cursor()
    id_curso = input("Ingrese el ID del curso: ")

    try:
        cursor.execute("""
            SELECT c.nombre, c.categoria, c.fecha_inicio, c.fecha_fin, u.nombre, u.apellido
            FROM Curso c
            JOIN Profesor p ON c.id_profesor = p.id_profesor
            JOIN Usuario u ON p.id_usuario = u.id_usuario
            WHERE c.id_curso = %s
        """, (id_curso,))
        curso = cursor.fetchone()
        if curso:
            print(f"\nCurso: {curso[0]} ({curso[1]})")
            print(f"Fechas: {curso[2]} a {curso[3]}")
            print(f"Profesor: {curso[4]} {curso[5]}")
        else:
            print("Curso no encontrado.")
            return

        print("\nEstudiantes inscritos:")
        cursor.execute("""
            SELECT u.nombre, u.apellido
            FROM Matricula m
            JOIN Estudiante e ON m.id_estudiante = e.id_estudiante
            JOIN Usuario u ON e.id_usuario = u.id_usuario
            WHERE m.id_curso = %s
        """, (id_curso,))
        estudiantes = cursor.fetchall()
        if estudiantes:
            for est in estudiantes:
                print(f"- {est[0]} {est[1]}")
        else:
            print("No hay estudiantes inscritos.")

    except Exception as e:
        print("Error:", e)
    finally:
        cursor.close()
        conn.close()

def listar_usuarios():
    conn = conectar()
    cursor = conn.cursor()

    print("\n Filtros de usuario:")
    print("1. Todos")
    print("2. Por ID de usuario")
    print("3. Por rol (administrador, profesor, estudiante)")
    filtro = input("Seleccione filtro: ")

    try:
        if filtro == "1":
            cursor.execute("SELECT id_usuario, nombre, apellido, email FROM Usuario")
        elif filtro == "2":
            id_usuario = input("Ingrese ID de usuario: ")
            cursor.execute("SELECT id_usuario, nombre, apellido, email FROM Usuario WHERE id_usuario = %s", (id_usuario,))
        elif filtro == "3":
            rol = input("Ingrese rol (administrador/profesor/estudiante): ").lower()
            if rol == "administrador":
                cursor.execute("""
                    SELECT u.id_usuario, u.nombre, u.apellido, u.email 
                    FROM Usuario u JOIN Administrador a ON u.id_usuario = a.id_usuario
                """)
            elif rol == "profesor":
                cursor.execute("""
                    SELECT u.id_usuario, u.nombre, u.apellido, u.email 
                    FROM Usuario u JOIN Profesor p ON u.id_usuario = p.id_usuario
                """)
            elif rol == "estudiante":
                cursor.execute("""
                    SELECT u.id_usuario, u.nombre, u.apellido, u.email 
                    FROM Usuario u JOIN Estudiante e ON u.id_usuario = e.id_usuario
                """)
            else:
                print("Rol inválido.")
                return
        else:
            print("Filtro inválido.")
            return

        print("\nUsuarios encontrados:")
        for u in cursor.fetchall():
            print(f"{u[0]}: {u[1]} {u[2]} - {u[3]}")

    except Exception as e:
        print("Error:", e)
    finally:
        cursor.close()
        conn.close()
